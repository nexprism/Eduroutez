import OverViewPage from './_components/overview';

export const metadata = {
  title: 'Dashboard : Overview'
};

export default function page() {
  return <OverViewPage />;
}
